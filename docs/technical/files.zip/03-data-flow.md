# Data Flow & Exactly-Once Delivery

## 1. Event Lifecycle — Complete Flow

```
    PUBLISHER SIDE              BROKER                         CONSUMER SIDE
    ==============              ======                         =============

 1. SDK serializes             
    payload to MsgPack         
                               
 2. SDK generates UUIDv7       
    message ID (or reuses      
    on retry)                  
                               
 3. SDK builds PUB frame       
    with CRC32                 
                               
 4. SDK sends over TCP/TLS ──> 5. Receive frame              
                                  Verify CRC32               
                               
                               6. Decode frame               
                                  Extract topic, msg_id      
                               
                               7. Permission check           
                                  session.can_publish(topic)  
                                  → FAIL: send ERR(4030)     
                               
                               8. Dedup check                
                                  bloom_filter.may_contain(id)
                                  → YES: sled.get(id)        
                                    → exists: send ACK       
                                      (status:"duplicate")   
                                  → NO: continue (new event) 
                               
                               9. WAL append + fsync         
                                  Record: EVENT_WRITE        
                                  → FAIL: send ERR(5000)     
                               
                              10. Dedup insert               
                                  bloom_filter.insert(id)    
                                  sled.insert(id, metadata)  
                               
                              11. Memory buffer insert        
                                  ring_buffer.push(event)    
                               
                              12. Send ACK(status:"stored")   
 13. SDK receives ACK ←────── 
     Publisher done ✓          
                              13. Route evaluation            
                                  match topic against rules  
                                  evaluate content filters   
                                  apply transforms           
                               
                              14. Fan-out to consumer queues  
                                  For each matched consumer: 
                                  delivery_queue.push(event) 
                               
                              15. Delivery: send PUB frame ──> 16. SDK receives frame
                                  to consumer via TCP/TLS         Verify CRC32
                                  Set state: DELIVERED            Decode payload
                                  Start ack_timeout timer    
                                                              17. Call user's handler
                                                                  function
                                                              
                                                              18a. Handler returns Ok
                                                                   → SDK sends ACK
                              19. Receive ACK ←──────────────      (status:"done")
                                  Mark event: COMPLETED       
                                  WAL: append COMPLETION     
                                  Remove from in-flight      
                                                              
                                                              18b. Handler returns Err
                                                                   → SDK sends NACK
                              19. Receive NACK                     (status:"rejected")
                                  Schedule retry             
                                  increment attempt counter  
                                  → if attempt > max_retries 
                                    → move to DLQ            
                                                              
                                                              18c. No response (timeout)
                              19. ack_timeout fires           
                                  Schedule retry             
                                  (same as NACK path)        
```

## 2. Exactly-Once Mechanics

Exactly-once delivery is achieved through the combination of three mechanisms:

### 2.1 Publisher-Side Deduplication

**Problem**: Publisher sends PUB, broker writes WAL, but ACK is lost on the network. Publisher retries, creating a potential duplicate.

**Solution**: Publisher always retries with the same Message ID. Broker deduplicates.

```
Timeline:
  t=0   Publisher sends PUB(id=abc)
  t=1   Broker writes WAL ✓
  t=2   Broker sends ACK → lost on network
  t=5   Publisher timeout, retries PUB(id=abc)  ← SAME ID
  t=6   Broker dedup: id=abc already in WAL
  t=7   Broker sends ACK(status:"duplicate")
  t=8   Publisher receives ACK ✓

Result: Event abc exists exactly once in WAL.
```

**SDK responsibility**: The SDK generates Message ID once and caches it until ACK is received. On reconnect, pending (unACKed) publishes are replayed with original IDs.

### 2.2 Broker-Side Deduplication Engine

Two-layer design for performance:

```
Layer 1: Bloom Filter (in-memory)
  ├── Capacity: 1,000,000 entries
  ├── False positive rate: 0.1%
  ├── Memory: ~1.2 MB
  ├── Lookup time: O(k) where k = number of hash functions (~7)
  └── Purpose: fast negative check — if bloom says NO, it's definitely new

Layer 2: sled Database (on disk, cached in memory by sled)
  ├── Key: msg_id (16 bytes)
  ├── Value: { timestamp, topic, state } (~64 bytes)
  ├── Purpose: exact check when bloom filter says MAYBE
  └── TTL: entries expire after 7 days (configurable)
```

**Dedup flow**:

```rust
pub async fn check(&self, msg_id: &MessageId) -> DedupResult {
    // Fast path: bloom filter says definitely not seen
    if !self.bloom.may_contain(msg_id) {
        return DedupResult::New;
    }

    // Slow path: bloom says maybe → check sled for certainty
    match self.db.get(msg_id)? {
        Some(_) => DedupResult::Duplicate,
        None => DedupResult::New,  // bloom false positive
    }
}

pub async fn insert(&self, msg_id: &MessageId, metadata: &EventMeta) {
    self.bloom.insert(msg_id);
    self.db.insert(msg_id, metadata)?;
}
```

**Bloom filter maintenance**:
- Rebuilt every 24 hours from sled (removes expired entries)
- During rebuild: old filter still serves reads; new filter swaps in atomically via `ArcSwap`

### 2.3 Consumer-Side Deduplication

**Problem**: Broker delivers event to consumer. Consumer processes it, sends ACK, but ACK is lost. Broker retries delivery. Consumer processes again → duplicate processing.

**Solution**: Consumer SDK tracks recently processed Message IDs.

```
Consumer SDK internal:
  processed_ids: LruCache<MessageId, ()>  // capacity: 10,000

On event received:
  if processed_ids.contains(msg_id):
    → send ACK immediately (already processed)
    → do NOT call user's handler
  else:
    → call user's handler
    → if Ok: insert msg_id into processed_ids, send ACK
    → if Err: send NACK (do not insert)
```

**Edge case**: Consumer restarts, LRU cache is lost. Broker re-delivers an event that was already processed before restart.

**Mitigation**: For consumers that cannot tolerate this, SDK provides optional persistent dedup:

```rust
pulse.subscribe_opts("payment.completed", SubscribeOpts {
    dedup: Dedup::Persistent("/var/lib/myservice/pulse-dedup"),
    ..Default::default()
}, |event| async move {
    // guaranteed exactly-once even across restarts
    Ok(())
}).await?;
```

This uses a local sled database on the consumer side. Default (in-memory LRU) is sufficient for most cases.

## 3. Failure Scenarios — Detailed

### 3.1 Broker Crash During WAL Write

```
Scenario: Broker crashes after partial write to WAL segment.

WAL segment on disk:
  [Record 1: complete, valid CRC] ✓
  [Record 2: complete, valid CRC] ✓
  [Record 3: partial, truncated]  ✗

Recovery:
  1. Open segment file
  2. Read records sequentially
  3. For each record: verify length field matches actual data, verify CRC32
  4. Record 3 fails CRC → truncate file at Record 2 boundary
  5. Record 3's event was never ACKed to publisher (crash happened before ACK)
  6. Publisher will timeout and retry → event written cleanly

Result: No data corruption. No duplicate. No loss.
```

### 3.2 Broker Crash After ACK, Before Delivery

```
Scenario: Event abc written to WAL, ACKed to publisher, broker crashes before delivery.

Recovery:
  1. WAL replay finds: abc has EVENT_WRITE record, no COMPLETION record
  2. abc is "pending" → re-enter routing pipeline
  3. Route evaluation produces delivery targets
  4. Events enqueued for delivery

Result: Event delivered, possibly with delay. No loss.
```

### 3.3 Broker Crash After Delivery, Before Consumer ACK

```
Scenario: Event abc delivered to consumer, consumer is processing, broker crashes.

Recovery:
  1. WAL replay: abc has EVENT_WRITE, no COMPLETION
  2. abc re-enters delivery pipeline
  3. Consumer may receive abc again (if consumer also reconnects)
  4. Consumer-side dedup catches duplicate

Result: No duplicate processing (dedup). No loss.
```

### 3.4 Consumer Crash During Processing

```
Scenario: Consumer receives abc, handler function panics/crashes.

Broker side:
  1. TCP connection drops → broker detects consumer disconnect
  2. All in-flight events for that consumer → state back to PENDING
  3. When consumer reconnects and re-subscribes → events re-delivered

Consumer side:
  1. Process restarts
  2. SDK auto-reconnects (exponential backoff)
  3. SDK re-sends all SUB frames
  4. Broker starts delivering pending events

Result: Event re-processed. Consumer dedup prevents duplicate side-effects.
```

### 3.5 Network Partition Between Broker and Consumer

```
Scenario: Consumer is alive but network path to broker is broken.

Broker side:
  1. PING/PONG fails after keepalive_timeout (30s)
  2. Broker marks consumer as disconnected
  3. In-flight events → state back to PENDING
  4. New events for this consumer → queued (up to max_pending)
  5. If queue exceeds max_pending → overflow to disk

Consumer side:
  1. SDK detects connection loss (PONG timeout or write error)
  2. SDK begins reconnect loop with backoff
  3. Network recovers → TCP reconnect → TLS → CONNECT → SUB
  4. Broker drains queued events to consumer

Result: Events delayed but not lost. Order preserved within topic.
```

### 3.6 Slow Consumer (Backpressure)

```
Scenario: Consumer handler takes 5 seconds per event, broker has 100 events queued.

Flow:
  1. Consumer sets max_inflight: 1 (via FLOW frame or connect config)
  2. Broker delivers 1 event
  3. Broker waits for ACK before delivering next
  4. Events accumulate in consumer's delivery queue (in-memory)
  5. If queue > max_pending_per_consumer:
     → Overflow to disk-backed queue
     → Publisher still receives ACK (event is durable)
     → No one is blocked except the slow consumer

Metrics emitted:
  - pulse_consumer_queue_depth{consumer="payment-svc"} = 100
  - pulse_consumer_queue_overflow{consumer="payment-svc"} = 1
  → Alerts can trigger on these
```

### 3.7 DLQ Flow

```
Scenario: Consumer consistently fails to process event abc.

Timeline:
  Attempt 1: deliver → handler returns Err → NACK
  (wait 1s)
  Attempt 2: deliver → handler returns Err → NACK
  (wait 2s)
  Attempt 3: deliver → handler returns Err → NACK
  (wait 4s)
  Attempt 4: deliver → handler returns Err → NACK
  (wait 8s)
  Attempt 5: deliver → handler returns Err → NACK
  → max_redeliveries reached

DLQ action:
  1. Event moved to DLQ topic: "dlq.{original_topic}"
     e.g., "dlq.order.created"
  2. DLQ event includes:
     - Original event payload
     - All headers
     - Delivery metadata: attempt count, first/last attempt timestamps
     - Last error reason (from NACK payload)
  3. Alert webhook fired (if configured in routes.yaml)
  4. Event state marked as DLQ in state DB
  5. DLQ events can be:
     - Inspected via admin API
     - Replayed (re-injected into original topic)
     - Purged after investigation
```

## 4. Event State Machine

Every event in the broker has a state tracked in the state DB:

```
                    ┌────────────┐
  PUB received ──>  │  RECEIVED  │  (frame validated, not yet written)
                    └─────┬──────┘
                          │ WAL write success
                          ▼
                    ┌────────────┐
                    │   STORED   │  (WAL durable, ACK sent to publisher)
                    └─────┬──────┘
                          │ routing resolved
                          ▼
                    ┌────────────┐
               ┌──> │  PENDING   │  (in consumer delivery queue)
               │    └─────┬──────┘
               │          │ sent to consumer
               │          ▼
               │    ┌────────────┐
  timeout/     │    │ DELIVERED  │  (sent, awaiting ACK)
  NACK         │    └─────┬──────┘
               │          │
               │     ┌────┴────┐
               │     │         │
               │   ACK OK    ACK FAIL or timeout
               │     │         │
               │     ▼         ▼
               │  ┌──────┐  ┌────────┐
               │  │ DONE │  │ RETRY  │  (schedule re-delivery)
               │  └──────┘  └───┬────┘
               │                │
               │    ┌───────────┴──────────┐
               │    │                      │
               │  attempt < max         attempt >= max
               │    │                      │
               └────┘                      ▼
                                     ┌──────────┐
                                     │   DLQ    │
                                     └──────────┘
```

**State storage:**

```rust
// sled key-value for event state
key:   msg_id (16 bytes)
value: EventState {
    state: State,              // enum: Received, Stored, Pending, Delivered, Done, Dlq
    topic: String,
    produced_at: u64,          // millis
    stored_at: u64,
    delivered_at: Option<u64>,
    completed_at: Option<u64>,
    attempt: u32,
    target_consumer: String,
    last_error: Option<String>,
}
```

**Note on fan-out**: If an event routes to N consumers, there are N state entries (keyed by `msg_id + consumer_id`). The event is DONE for the system when all N entries are DONE (or DLQ).

## 5. Exactly-Once Summary

```
Publisher → Broker:
  Guarantee: exactly-once write to WAL
  Mechanism: UUIDv7 Message ID + broker dedup engine
  SDK role:  retry with same ID, cache ID until ACK received

Broker → Consumer:
  Guarantee: at-least-once delivery + consumer dedup = exactly-once processing
  Mechanism: broker retries on timeout/NACK, consumer SDK dedup cache
  SDK role:  LRU cache of processed IDs (optional: persistent sled)
  User role: design idempotent handlers as defense-in-depth

End-to-end:
  Each event is written once, delivered once (effectively), processed once.
  Edge case: consumer restart without persistent dedup → at-least-once
  Mitigation: enable persistent dedup for critical consumers
```

## 6. Performance Characteristics

| Operation | Expected Latency | Notes |
|-----------|-----------------|-------|
| PUB → ACK (stored) | 1-5 ms | Dominated by WAL fsync |
| Route evaluation | <0.1 ms | In-memory, DashMap lookup |
| Delivery (in-flight) | <1 ms | TCP write to connected consumer |
| End-to-end (PUB → consumer handler) | 2-10 ms | Sum of above |
| Dedup check (bloom hit: no) | <0.01 ms | Pure memory |
| Dedup check (bloom hit: yes) | <0.5 ms | sled lookup |
| Recovery (100K events) | ~2 seconds | Sequential WAL replay |

All latencies assume SSD storage and same-region network. Internet (cross-region) adds network RTT.
