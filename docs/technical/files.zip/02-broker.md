# Pulse Broker — Internal Design

## 1. Module Architecture

```
pulse-broker binary
│
├── main.rs                    — CLI, config loading, signal handling
│
├── server/
│   ├── listener.rs            — TCP + TLS accept loop
│   ├── connection.rs          — Per-connection read/write loop
│   └── session.rs             — Authenticated session state
│
├── pipeline/
│   ├── ingest.rs              — Receive PUB, validate, assign to pipeline
│   ├── dedup.rs               — Bloom filter + sled dedup engine
│   ├── wal.rs                 — Write-Ahead Log manager
│   └── dispatcher.rs          — Coordinate ingest → dedup → wal → route
│
├── routing/
│   ├── engine.rs              — Topic matching + content filter evaluation
│   ├── filter.rs              — Expression parser and evaluator
│   ├── transform.rs           — Payload transform operations
│   └── config.rs              — Route config hot-reload
│
├── delivery/
│   ├── manager.rs             — Per-consumer queue management
│   ├── queue.rs               — In-memory queue with disk overflow
│   ├── retry.rs               — Retry scheduler (exponential backoff)
│   ├── ack_tracker.rs         — Track in-flight deliveries, detect timeouts
│   └── dlq.rs                 — Dead Letter Queue handler
│
├── storage/
│   ├── wal_segment.rs         — WAL segment file read/write
│   ├── compaction.rs          — Segment compaction and cleanup
│   ├── state_db.rs            — sled wrapper for event state, subscriptions
│   └── recovery.rs            — Crash recovery: WAL replay logic
│
├── auth/
│   ├── authenticator.rs       — API Key + HMAC verification
│   ├── permissions.rs         — Topic-level ACL checks
│   └── config.rs              — services.yaml parser, hot-reload
│
├── namespace/
│   ├── registry.rs            — Namespace lifecycle management
│   └── isolation.rs           — Topic/service scoping per namespace
│
├── protocol/
│   ├── frame.rs               — Frame encode/decode, CRC verify
│   ├── codec.rs               — tokio codec for framing TCP stream
│   └── types.rs               — Message type enums and payload structs
│
├── metrics/
│   ├── counters.rs            — Event counters, error rates
│   ├── histograms.rs          — Latency distributions
│   └── exporter.rs            — Prometheus HTTP endpoint
│
└── config/
    ├── broker.rs              — Broker-level config (ports, limits, paths)
    ├── routes.rs              — Route rules config
    └── loader.rs              — YAML/TOML loader with hot-reload
```

## 2. Concurrency Model

The broker uses `tokio` for all async operations. No thread-per-connection. Key concurrency primitives:

### Task Layout

```
┌─────────────────────────────────────────────────────────┐
│                    tokio Runtime                         │
│                                                         │
│  Task: TLS Listener                                     │
│    └─ accept() loop → spawn Connection task per client  │
│                                                         │
│  Task: Connection(service_a)                             │
│    └─ read frames → send to pipeline_tx channel         │
│    └─ read from delivery_rx channel → write frames      │
│                                                         │
│  Task: Connection(service_b)                             │
│    └─ (same pattern)                                    │
│                                                         │
│  Task: Pipeline Processor                                │
│    └─ recv from pipeline_tx → dedup → WAL → route       │
│    └─ fan-out to per-consumer delivery_tx channels      │
│                                                         │
│  Task: Delivery(consumer_1)                              │
│    └─ recv from delivery_tx → send frame → track ACK    │
│    └─ timeout check → retry                             │
│                                                         │
│  Task: WAL Compactor                                     │
│    └─ periodic: compact completed segments              │
│                                                         │
│  Task: Config Watcher                                    │
│    └─ inotify on config files → reload routes/auth      │
│                                                         │
│  Task: Metrics Server                                    │
│    └─ HTTP /metrics endpoint for Prometheus              │
│                                                         │
│  Task: Health Check                                      │
│    └─ HTTP /health and /ready endpoints                 │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

### Internal Channels

All inter-task communication uses `tokio::mpsc` bounded channels. Sizes are configurable.

```
Connection task ──mpsc(1024)──> Pipeline Processor
                                      │
                                      ├──mpsc(4096)──> Delivery(consumer_1)
                                      ├──mpsc(4096)──> Delivery(consumer_2)
                                      └──mpsc(4096)──> Delivery(consumer_n)

Delivery task ──mpsc(1024)──> Connection task (write path)
```

**Backpressure**: when a channel is full, the sender `.send().await` blocks. This propagates backpressure naturally:
- If consumer is slow → delivery channel fills → pipeline blocks on fan-out → ingest slows → TCP read slows → publisher sees write backpressure

### Shared State (concurrent access)

| Data | Structure | Access Pattern |
|------|-----------|----------------|
| Routing table | `DashMap<TopicPattern, Vec<ConsumerRef>>` | Read-heavy, write on SUB/UNSUB |
| Active sessions | `DashMap<ServiceId, SessionHandle>` | Read on route, write on connect/disconnect |
| Subscription registry | `DashMap<SubId, Subscription>` | Read on deliver, write on SUB/UNSUB |
| Dedup bloom filter | `RwLock<BloomFilter>` | Read on every PUB, rebuild periodically |
| Config (routes, auth) | `ArcSwap<Config>` | Read on every operation, write on reload |

## 3. Connection Lifecycle (Detailed)

```rust
// Pseudocode for connection handling
async fn handle_connection(tls_stream: TlsStream, broker: BrokerHandle) {
    let codec = PulseCodec::new();
    let (mut reader, mut writer) = codec.framed(tls_stream).split();

    // Step 1: Await CONNECT frame (5s timeout)
    let connect_frame = timeout(5.sec(), reader.next()).await??;
    let session = broker.authenticate(connect_frame)?;

    // Step 2: Send CONNACK
    writer.send(Frame::connack(&session)).await?;

    // Step 3: Create delivery channel for this session
    let (deliver_tx, mut deliver_rx) = mpsc::channel(4096);
    broker.register_session(session.id(), deliver_tx);

    // Step 4: Bidirectional loop
    loop {
        tokio::select! {
            // Inbound: frames from client
            frame = reader.next() => {
                match frame??.msg_type() {
                    Type::PUB => broker.pipeline_tx.send(Ingest { frame, session }).await?,
                    Type::ACK => broker.delivery.ack(frame.msg_id(), session.id()),
                    Type::SUB => broker.subscribe(frame, &session).await?,
                    Type::UNSUB => broker.unsubscribe(frame, &session).await?,
                    Type::PING => writer.send(Frame::pong(frame.msg_id())).await?,
                    Type::FLOW => broker.delivery.flow_control(frame, &session),
                    _ => writer.send(Frame::err(4000, "unexpected type")).await?,
                }
            }
            // Outbound: events to deliver to this client
            event = deliver_rx.recv() => {
                writer.send(event?.to_frame()).await?;
            }
            // Keepalive: send PING if idle
            _ = tokio::time::sleep(keepalive_interval) => {
                writer.send(Frame::ping()).await?;
            }
        }
    }

    // Cleanup on disconnect
    broker.unregister_session(session.id());
}
```

## 4. Pipeline Processor (Core Loop)

The pipeline processor is the single point where all events flow through. This is intentionally serial per-namespace to guarantee ordering.

```rust
// Pseudocode
async fn pipeline_loop(
    mut rx: mpsc::Receiver<IngestMessage>,
    dedup: DedupEngine,
    wal: WalWriter,
    router: Router,
    delivery: DeliveryManager,
) {
    while let Some(msg) = rx.recv().await {
        let frame = &msg.frame;
        let session = &msg.session;
        let msg_id = frame.msg_id();

        // 1. Permission check
        if !session.can_publish(frame.topic()) {
            msg.reply(Frame::err(4030, "forbidden")).await;
            continue;
        }

        // 2. Dedup
        match dedup.check(msg_id).await {
            DedupResult::New => { /* continue */ }
            DedupResult::Duplicate => {
                msg.reply(Frame::ack(msg_id, "duplicate")).await;
                continue;
            }
        }

        // 3. WAL write (fsync)
        if let Err(e) = wal.append(frame).await {
            metrics::counter!("wal_write_errors").increment(1);
            msg.reply(Frame::err(5000, "wal write failed")).await;
            continue;
        }

        // 4. Register in dedup (after successful WAL write)
        dedup.insert(msg_id).await;

        // 5. Insert into memory buffer
        // (used for late subscribers with position: "earliest" within buffer window)

        // 6. ACK to publisher — event is now durable
        msg.reply(Frame::ack(msg_id, "stored")).await;

        // 7. Route
        let targets = router.resolve(frame.topic(), frame.payload());

        // 8. Fan-out to delivery queues
        for target in targets {
            let event = DeliveryEvent {
                msg_id,
                topic: frame.topic().to_owned(),
                payload: frame.payload().clone(),
                headers: frame.headers().clone(),
                attempt: 1,
            };
            if let Err(_) = delivery.enqueue(target, event).await {
                metrics::counter!("delivery_enqueue_overflow").increment(1);
                // Overflow to disk — see delivery/queue.rs
            }
        }
    }
}
```

**Ordering guarantee**: events from the same publisher to the same topic are processed in order because:
1. TCP guarantees ordered delivery
2. Pipeline is sequential per received order
3. Per-consumer delivery queue preserves insertion order

## 5. Session State

```rust
pub struct Session {
    pub id: SessionId,             // unique per connection
    pub service_id: String,        // "order-service"
    pub namespace: String,         // "ecommerce"
    pub connected_at: Instant,
    pub permissions: Permissions,  // publish/subscribe ACLs
    pub subscriptions: Vec<SubId>, // active subscriptions
    pub codec: Codec,              // msgpack or json
    pub max_inflight: u32,         // flow control limit
    pub deliver_tx: mpsc::Sender<DeliveryEvent>, // channel to this connection's write loop
}

pub struct Permissions {
    pub publish_topics: Vec<TopicPattern>,   // ["order.*"]
    pub subscribe_topics: Vec<TopicPattern>, // ["payment.*", "inventory.*"]
}
```

## 6. Graceful Shutdown

```
SIGTERM received
  │
  ▼
1. Stop accepting new connections
  │
  ▼
2. Send ERR(5030, "shutting down") to all connected clients
  │
  ▼
3. Wait up to 30s for in-flight ACKs
  │
  ▼
4. Flush WAL (fsync)
  │
  ▼
5. Close sled DB
  │
  ▼
6. Exit 0
```

In-flight events that haven't been ACKed will be re-delivered on next startup (WAL recovery).

## 7. Configuration

### broker.yaml

```yaml
# Network
listen_addr: "0.0.0.0:4222"
tls:
  cert_path: "/etc/pulse/cert.pem"
  key_path: "/etc/pulse/key.pem"

# Limits
max_connections: 5000
max_payload_bytes: 1048576           # 1 MB
max_pending_per_consumer: 10000

# Keepalive
keepalive_interval_secs: 10
keepalive_timeout_secs: 30
connect_timeout_secs: 5

# Storage
data_dir: "/var/lib/pulse"
wal:
  segment_size_bytes: 67108864       # 64 MB
  sync_mode: "fsync"                 # "fsync" | "fdatasync" | "none" (testing only)
  retention_hours: 168               # 7 days

# Delivery
delivery:
  ack_timeout_secs: 30
  max_redeliveries: 5
  backoff:
    initial_secs: 1
    max_secs: 60
    multiplier: 2.0

# Compaction
compaction:
  interval_secs: 3600                # run every hour
  min_completed_ratio: 0.8           # compact when 80% events done

# Metrics
metrics:
  enabled: true
  listen_addr: "0.0.0.0:9090"
  path: "/metrics"

# Health
health:
  listen_addr: "0.0.0.0:8080"
```

### services.yaml (hot-reloadable)

```yaml
namespaces:
  ecommerce:
    services:
      order-service:
        key: "psk_live_7f3a8b2c4d5e6f7a8b9c0d1e2f3a4b5c"
        permissions:
          publish: ["order.*"]
          subscribe: ["payment.*", "inventory.*"]

      payment-service:
        key: "psk_live_9d4e1f5a6b7c8d9e0f1a2b3c4d5e6f7a"
        permissions:
          publish: ["payment.*"]
          subscribe: ["order.created"]

      analytics-service:
        key: "psk_live_1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d"
        permissions:
          publish: []
          subscribe: ["*"]   # can subscribe to everything

  internal-tools:
    services:
      deploy-service:
        key: "psk_live_abc123..."
        permissions:
          publish: ["deploy.*"]
          subscribe: ["deploy.*"]
```

### Hot Reload Mechanism

```
Config Watcher task:
  1. inotify watch on services.yaml and routes.yaml
  2. On file change → parse new config
  3. Validate: all keys unique, topics valid, no syntax errors
  4. If valid → ArcSwap::store(new_config)
     All subsequent operations read new config immediately
  5. If invalid → log error, keep old config, emit metric
  6. No connections are dropped during reload
```
