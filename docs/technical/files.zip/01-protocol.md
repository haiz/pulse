# Pulse Protocol Specification v1.0

## 1. Design Goals

- **Minimal overhead**: binary framing, no HTTP layer, no schema compilation step
- **Self-describing**: every frame carries enough info to decode without external state
- **Integrity**: CRC32 on every frame to detect corruption
- **Sortable IDs**: UUIDv7 message IDs encode creation timestamp
- **Simple to implement**: 9 message types cover all use cases

## 2. Transport Layer

- **Transport**: TCP with mandatory TLS 1.3 (via `rustls`)
- **Default port**: 4222
- **Byte order**: Big-endian (network byte order) for all multi-byte integers
- **Connection**: persistent, full-duplex — both sides can send frames at any time
- **Keepalive**: PING/PONG at configurable interval (default: 10 seconds)

## 3. Frame Format

Every message on the wire is a single frame:

```
 0                   1                   2                   3
 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|         Magic (0x50 0x4C)     |   Version     |     Type      |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|     Flags     |                                               |
+-+-+-+-+-+-+-+-+                                               +
|                                                               |
+                       Message ID (16 bytes)                   +
|                          UUIDv7                                |
+                                               +-+-+-+-+-+-+-+-+
|                                               |               |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+               +
|                    Payload Length (4 bytes)                    |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|                                                               |
|                     Payload (variable)                         |
|                   MessagePack encoded                          |
|                                                               |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|                       CRC32 (4 bytes)                         |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
```

### Field Reference

| Field | Offset | Size | Description |
|-------|--------|------|-------------|
| Magic | 0 | 2 bytes | Always `0x504C` (ASCII "PL" for Pulse). Used to detect stream misalignment. |
| Version | 2 | 1 byte | Protocol version. Currently `0x01`. |
| Type | 3 | 1 byte | Message type (see §4). |
| Flags | 4 | 1 byte | Bitfield (see §3.1). |
| Message ID | 5 | 16 bytes | UUIDv7. For PUB frames, this is the event ID used for dedup. For other frames, used for request-response correlation. |
| Payload Length | 21 | 4 bytes | Length of payload in bytes. Max: 16 MB (`0x01000000`). 0 for frames with no payload (PING, PONG, UNSUB). |
| Payload | 25 | variable | MessagePack-encoded data. Structure depends on message type. |
| CRC32 | 25 + len | 4 bytes | CRC32C (Castagnoli) over bytes [0, 25+len). Covers header + payload. |

**Total header size**: 25 bytes (fixed) + payload + 4 bytes CRC = 29 bytes overhead minimum.

### 3.1 Flags Bitfield

```
Bit 0: COMPRESSED    — payload is LZ4-compressed (0 = raw, 1 = compressed)
Bit 1: BATCH         — payload contains multiple messages (0 = single, 1 = batch)
Bit 2: REPLY_TO      — payload includes a reply_to field for request-reply pattern
Bit 3: PRIORITY      — high-priority message, skip to front of delivery queue
Bits 4-7: RESERVED   — must be 0, ignored by receiver
```

### 3.2 Maximum Frame Size

- Maximum payload: 16 MB (configurable, default 1 MB)
- Maximum total frame: 16 MB + 29 bytes
- Frames exceeding the configured max are rejected with ERR frame

## 4. Message Types

### 4.1 CONNECT (0x01) — Client → Broker

Sent immediately after TLS handshake. Must be the first frame on a new connection.

**Payload (MessagePack map):**

```
{
  "service_id":  "order-service",          // string, required
  "namespace":   "ecommerce",              // string, required
  "timestamp":   1700000000,               // uint64, Unix epoch seconds, required
  "hmac":        <32 bytes>,               // bytes, HMAC-SHA256(api_key, timestamp), required
  "client_ver":  "pulse-sdk-rust/0.1.0",   // string, optional
  "max_inflight": 10,                      // uint32, optional, default 100
  "codec":       "msgpack"                 // string, optional, "msgpack" | "json"
}
```

**Authentication flow:**
1. Client computes `HMAC-SHA256(api_key, timestamp_as_string)`
2. Broker looks up `api_key` by `service_id` + `namespace`
3. Broker verifies HMAC
4. Broker checks `|timestamp - server_time| < 30 seconds` (anti-replay)
5. If valid → CONNACK. If invalid → ERR + close connection.

### 4.2 CONNACK (0x02) — Broker → Client

**Payload:**

```
{
  "status":      "ok",                     // "ok" | "error"
  "broker_id":   "pulse-broker-01",        // string
  "server_time": 1700000001,               // uint64, for client clock sync
  "max_payload": 1048576,                  // uint32, max payload bytes
  "features":    ["batch", "compress"]     // string array, supported features
}
```

### 4.3 PUB (0x03) — Client → Broker

Publish an event to a topic.

**Payload:**

```
{
  "topic":      "order.created",           // string, required, max 255 chars
  "data":       <arbitrary msgpack>,       // any, required — the event payload
  "headers":    {                          // map, optional — metadata
    "trace_id":    "abc123",
    "reply_to":    "inbox.svc.abc123",     // only if REPLY_TO flag set
    "priority":    "high"
  },
  "produced_at": 1700000000000             // uint64, optional, millis since epoch
}
```

**Message ID**: the frame's Message ID field is the unique event ID. Publishers must reuse the same Message ID when retrying a failed publish to enable dedup.

### 4.4 ACK (0x04) — Bidirectional

Used for two purposes:
1. **Broker → Publisher**: acknowledges event stored in WAL (ACK STORED)
2. **Consumer → Broker**: acknowledges event processed (ACK DONE)

**Payload:**

```
{
  "status":   "stored" | "done" | "rejected" | "duplicate",
  "msg_id":   <16 bytes>,                 // echoes the Message ID being ACKed
  "reason":   "payload_too_large"          // string, only present if "rejected"
}
```

**The frame's Message ID**: matches the original PUB frame's Message ID.

### 4.5 SUB (0x05) — Client → Broker

Subscribe to a topic pattern.

**Payload:**

```
{
  "topic":      "order.*",                 // string, required, supports wildcards
  "group":      "payment-processors",      // string, optional — consumer group name
  "filter":     "payload.amount > 1000",   // string, optional — content-based filter
  "position":   "latest" | "earliest",     // string, optional, default "latest"
  "sub_id":     "sub_001"                  // string, required — client-assigned subscription ID
}
```

**Wildcard rules:**
- `*` matches exactly one segment: `order.*` matches `order.created`, not `order.us.created`
- `>` matches one or more segments: `order.>` matches `order.created` and `order.us.created`
- Exact match has highest priority, then `*`, then `>`

**Broker responds with ACK** (status "ok") or ERR if topic pattern is invalid or permission denied.

### 4.6 UNSUB (0x06) — Client → Broker

**Payload:**

```
{
  "sub_id": "sub_001"                      // string, required — matches the SUB's sub_id
}
```

Broker responds with ACK.

### 4.7 PING (0x07) / PONG (0x08) — Bidirectional

No payload (payload length = 0). Either side can initiate.

- Client sends PING, broker responds PONG (and vice versa)
- If no PONG received within `keepalive_timeout` (default 30s), connection is considered dead
- Message ID field is echoed in PONG for correlation

### 4.8 FLOW (0x09) — Client → Broker

Flow control signal from consumer.

**Payload:**

```
{
  "max_inflight": 5,                       // uint32, required — max unACKed messages
  "sub_id":       "sub_001"                // string, optional — apply to specific sub, or all if omitted
}
```

Broker will not deliver more than `max_inflight` unACKed messages to this consumer (per subscription or globally).

### 4.9 ERR (0x0A) — Broker → Client

**Payload:**

```
{
  "code":    4010,                          // uint32, error code
  "message": "authentication failed"       // string, human-readable
}
```

**Error codes:**

| Code | Meaning |
|------|---------|
| 4000 | Bad request — malformed frame |
| 4001 | Invalid CRC — frame corrupted |
| 4010 | Authentication failed |
| 4030 | Forbidden — no permission for topic |
| 4040 | Namespace not found |
| 4090 | Payload too large |
| 4290 | Rate limited |
| 5000 | Internal broker error |
| 5030 | Broker shutting down |

## 5. Connection Lifecycle

```
Client                                    Broker
  │                                         │
  │ ──── TLS Handshake ──────────────────>  │
  │ <─── TLS Established ────────────────   │
  │                                         │
  │ ──── CONNECT { service_id, hmac } ──>   │
  │ <─── CONNACK { ok, features } ───────   │
  │                                         │
  │ ──── SUB { topic, sub_id } ──────────>  │
  │ <─── ACK { ok } ────────────────────    │
  │                                         │
  │         ... normal operation ...         │
  │                                         │
  │ ──── PING ───────────────────────────>  │
  │ <─── PONG ──────────────────────────    │
  │                                         │
  │    (graceful shutdown)                  │
  │ ──── UNSUB { sub_id } ──────────────>   │
  │ <─── ACK ───────────────────────────    │
  │ ──── TCP FIN ────────────────────────>  │
```

**Timeout rules:**
- CONNECT must arrive within 5 seconds of TLS completion, else broker closes
- PING/PONG timeout: 30 seconds (configurable)
- Idle connection without PING: broker sends PING after `keepalive` interval

## 6. Delivery Semantics on the Wire

### Publisher → Broker (PUB/ACK)

```
Publisher                      Broker
  │                              │
  │ ── PUB(id=X, topic, data) ──>│
  │                              │  1. Dedup check
  │                              │  2. WAL write + fsync
  │                              │  3. Memory buffer insert
  │ <── ACK(id=X, "stored") ──── │
  │                              │
  │  (if no ACK within 5s)       │
  │ ── PUB(id=X, same) ────────> │  (dedup: already stored)
  │ <── ACK(id=X, "duplicate") ──│
```

### Broker → Consumer (DELIVER/ACK)

Broker reuses PUB frame type (0x03) for delivery with an additional header:

```
{
  "topic":       "order.created",
  "data":        <original payload>,
  "headers":     { ...original headers... },
  "delivery": {                            // added by broker
    "attempt":     1,                      // retry count
    "first_sent":  1700000000000,          // millis, first delivery attempt
    "msg_id":      <original msg ID>
  }
}
```

Consumer sends ACK(id=X, "done") after processing.

**Retry policy:**
- No ACK within `ack_timeout` (default 30s) → redeliver
- Backoff: 1s, 2s, 4s, 8s, 16s, 30s, 30s, 30s... (exponential, capped)
- After `max_redeliveries` (default 5) → move to DLQ

## 7. Batch Mode

When BATCH flag (bit 1) is set, the payload contains an array of messages:

```
[
  { "topic": "order.created", "data": {...} },
  { "topic": "order.updated", "data": {...} },
  { "topic": "inventory.reserved", "data": {...} }
]
```

Broker treats batch atomically:
- All messages written to WAL in a single fsync
- Single ACK for the entire batch (references the batch frame's Message ID)
- If any message fails validation → entire batch rejected

## 8. Topic Naming Convention

```
{namespace}/{segment}.{segment}.{segment}
            └──── topic within namespace ────┘

Segment rules:
- Lowercase alphanumeric + hyphens: [a-z0-9-]
- Max 63 chars per segment
- Max 10 segments
- Max 255 chars total topic length
- No leading/trailing dots

Examples:
  order.created
  payment.completed
  user.profile.updated
  inventory.warehouse-hanoi.stock-changed
```

## 9. Compression

When COMPRESSED flag is set:
1. Payload is LZ4-compressed before framing
2. `Payload Length` field reflects compressed size
3. Receiver decompresses after CRC verification
4. Compression recommended for payloads > 1KB

## 10. Protocol Negotiation

The CONNACK `features` array tells the client what the broker supports:

| Feature string | Meaning |
|----------------|---------|
| `"batch"` | Batch publish supported |
| `"compress"` | LZ4 compression supported |
| `"filter"` | Content-based filtering supported |
| `"groups"` | Consumer groups supported |
| `"request_reply"` | Request-reply pattern supported |

Client must not use features not listed in CONNACK.
