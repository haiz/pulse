# Pulse — Architecture Overview

## 1. What is Pulse?

Pulse is a lightweight, high-performance event broker written in Rust. It enables services within an organization to communicate through events — reliably, quickly, and with minimal integration effort.

**Design philosophy:** Simple by default, powerful when needed.

## 2. Core Guarantees

| Guarantee | Implementation |
|-----------|---------------|
| **Exactly-once delivery** | At-least-once transport + deduplication at broker and consumer |
| **100% durability** | Write-Ahead Log (WAL) with fsync before ACK |
| **Ordering** | Per-topic ordering within a single publisher |
| **Low latency** | In-memory hot path, persistent TCP connections, binary protocol |

## 3. High-Level Architecture

```
┌─────────────┐  ┌─────────────┐  ┌─────────────┐
│  Service A  │  │  Service B  │  │  Service C  │
│ (publisher) │  │ (subscriber)│  │  (both)     │
└──────┬──────┘  └──────┬──────┘  └──────┬──────┘
       │                │                │
       │    Pulse Protocol (TCP + TLS)   │
       │         Binary frames           │
       ▼                ▼                ▼
┌─────────────────────────────────────────────────┐
│                  PULSE BROKER                    │
│                                                  │
│  ┌────────────────────────────────────────────┐  │
│  │            Connection Manager              │  │
│  │  - TLS termination (rustls)                │  │
│  │  - Session management                      │  │
│  │  - Authentication (API Key + HMAC)         │  │
│  │  - Backpressure / flow control             │  │
│  └───────────────────┬────────────────────────┘  │
│                      │                           │
│  ┌───────────────────▼────────────────────────┐  │
│  │             Message Pipeline                │  │
│  │                                             │  │
│  │  Ingest → Dedup → WAL Write → Route →      │  │
│  │  Filter → Transform → Fan-out → Deliver    │  │
│  └───────────────────┬────────────────────────┘  │
│                      │                           │
│  ┌───────────────────▼────────────────────────┐  │
│  │            Delivery Manager                 │  │
│  │  - Per-consumer queues                      │  │
│  │  - Retry scheduler (exponential backoff)    │  │
│  │  - ACK tracker                              │  │
│  │  - Dead Letter Queue (DLQ)                  │  │
│  └────────────────────────────────────────────┘  │
│                                                  │
│  ┌────────────┐ ┌────────────┐ ┌──────────────┐  │
│  │  WAL Disk  │ │  State DB  │ │   Metrics    │  │
│  │  (append)  │ │  (sled)    │ │  (tracing)   │  │
│  └────────────┘ └────────────┘ └──────────────┘  │
└─────────────────────────────────────────────────┘
```

## 4. Technology Stack

| Component | Crate | Purpose |
|-----------|-------|---------|
| Async runtime | `tokio` | All async I/O, timers, task spawning |
| TLS | `rustls` | Pure-Rust TLS (no OpenSSL dependency) |
| Embedded DB | `sled` | Event state, dedup index, consumer offsets |
| Serialization | `serde` + `rmp-serde` | MessagePack codec for payloads |
| Concurrent maps | `dashmap` | Lock-free routing table, subscription registry |
| Integrity | `crc32fast` | Frame-level CRC32 checksum |
| Message IDs | `uuid` (v7) | Time-sortable unique identifiers |
| Observability | `tracing` + `tracing-subscriber` | Structured logging and spans |
| Metrics | `metrics` + `metrics-exporter-prometheus` | Prometheus-compatible metrics |

## 5. Namespace Isolation

```
pulse://service:key@broker:4222/namespace
                                ─────────
                                isolation boundary

Namespace "ecommerce"          Namespace "internal-tools"
├── topic: order.*             ├── topic: ticket.*
├── topic: payment.*           ├── topic: deploy.*
├── services: order-svc,       ├── services: jira-bot,
│             payment-svc      │             deploy-svc
└── independent routing rules  └── independent routing rules
```

Namespaces are fully isolated: topics, services, routing rules, quotas. A service in namespace A cannot see or interact with namespace B.

## 6. Capacity Planning

Single broker on a 2-core / 4GB VPS:

| Metric | Capacity |
|--------|----------|
| Throughput | ~10,000 events/sec |
| Concurrent connections | ~5,000 |
| Memory (10K pending msgs) | ~200MB |
| WAL write speed | ~50MB/s (SSD) |

Target workload (10 events/sec) uses < 0.1% of capacity.

## 7. Document Index

| Document | Contents |
|----------|----------|
| `01-protocol.md` | Wire protocol specification — frame format, message types, handshake |
| `02-broker.md` | Broker internals — module architecture, internal channels, concurrency model |
| `03-data-flow.md` | Event lifecycle — publish to ACK, failure handling, exactly-once mechanics |
| `04-wal-storage.md` | WAL design, segment management, compaction, crash recovery |
| `05-routing.md` | Routing pipeline — topic matching, content filters, transforms, DLQ |
| `06-sdk.md` | SDK architecture — public API, internals, multi-language strategy |
| `07-project-structure.md` | Rust workspace layout, crate boundaries, build & test |
| `08-operations.md` | Deployment, configuration, monitoring, troubleshooting |
