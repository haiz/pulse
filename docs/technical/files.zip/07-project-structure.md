# Rust Project Structure

## 1. Workspace Layout

```
pulse/
├── Cargo.toml                    # workspace root
├── README.md
├── LICENSE
├── .github/
│   └── workflows/
│       ├── ci.yml                # test + clippy + fmt on every PR
│       └── release.yml           # build binaries + publish crates
│
├── crates/
│   ├── pulse-protocol/           # Wire protocol (shared by broker + SDK)
│   │   ├── Cargo.toml
│   │   └── src/
│   │       ├── lib.rs
│   │       ├── frame.rs          # Frame encode/decode
│   │       ├── codec.rs          # tokio Encoder/Decoder impl
│   │       ├── types.rs          # MessageType enum, payload structs
│   │       ├── message_id.rs     # UUIDv7 wrapper
│   │       └── crc.rs            # CRC32C helpers
│   │
│   ├── pulse-broker/             # Broker binary
│   │   ├── Cargo.toml
│   │   └── src/
│   │       ├── main.rs           # CLI, config load, signal handling
│   │       ├── server/
│   │       │   ├── mod.rs
│   │       │   ├── listener.rs   # TCP + TLS accept loop
│   │       │   ├── connection.rs # Per-connection handler
│   │       │   └── session.rs    # Authenticated session state
│   │       ├── pipeline/
│   │       │   ├── mod.rs
│   │       │   ├── ingest.rs     # Receive + validate PUB frames
│   │       │   ├── dedup.rs      # Bloom filter + sled dedup
│   │       │   ├── wal.rs        # WAL writer + group commit
│   │       │   └── dispatcher.rs # Orchestrate ingest → route
│   │       ├── routing/
│   │       │   ├── mod.rs
│   │       │   ├── engine.rs     # Topic trie + resolution
│   │       │   ├── filter.rs     # Expression parser + evaluator
│   │       │   ├── transform.rs  # Payload transform ops
│   │       │   └── config.rs     # routes.yaml loader + hot reload
│   │       ├── delivery/
│   │       │   ├── mod.rs
│   │       │   ├── manager.rs    # Per-consumer queue orchestration
│   │       │   ├── queue.rs      # Memory + disk overflow queue
│   │       │   ├── retry.rs      # Exponential backoff scheduler
│   │       │   ├── ack_tracker.rs# In-flight tracking + timeout
│   │       │   └── dlq.rs        # Dead Letter Queue
│   │       ├── storage/
│   │       │   ├── mod.rs
│   │       │   ├── wal_segment.rs# WAL segment file format
│   │       │   ├── compaction.rs # Segment compaction
│   │       │   ├── state_db.rs   # sled wrapper
│   │       │   └── recovery.rs   # Crash recovery (WAL replay)
│   │       ├── auth/
│   │       │   ├── mod.rs
│   │       │   ├── authenticator.rs
│   │       │   └── permissions.rs
│   │       ├── namespace/
│   │       │   ├── mod.rs
│   │       │   └── registry.rs
│   │       ├── metrics/
│   │       │   ├── mod.rs
│   │       │   └── exporter.rs   # Prometheus /metrics endpoint
│   │       └── config/
│   │           ├── mod.rs
│   │           ├── broker.rs     # broker.yaml schema
│   │           ├── services.rs   # services.yaml schema
│   │           ├── routes.rs     # routes.yaml schema
│   │           └── loader.rs     # File watcher + hot reload
│   │
│   ├── pulse-sdk/                # Rust SDK library
│   │   ├── Cargo.toml
│   │   └── src/
│   │       ├── lib.rs            # Public API re-exports
│   │       ├── client.rs         # Pulse struct (main entry point)
│   │       ├── builder.rs        # PulseBuilder
│   │       ├── connection.rs     # Connection manager + reconnect
│   │       ├── publish.rs        # Publish API + retry logic
│   │       ├── subscribe.rs      # Subscribe API + handler dispatch
│   │       ├── request_reply.rs  # Request-reply pattern
│   │       ├── stream.rs         # Stream API
│   │       ├── dedup.rs          # Consumer-side dedup (LRU + sled)
│   │       ├── error.rs          # PulseError enum
│   │       ├── types.rs          # Event, EventMeta, Headers, etc.
│   │       ├── url.rs            # Connection URL parser
│   │       └── mock.rs           # MockPulse for testing
│   │
│   ├── pulse-ffi/                # C ABI for foreign language SDKs
│   │   ├── Cargo.toml
│   │   ├── cbindgen.toml         # C header generation config
│   │   └── src/
│   │       ├── lib.rs            # #[no_mangle] extern "C" functions
│   │       ├── handle.rs         # Opaque pointer management
│   │       └── error.rs          # Error codes for C callers
│   │
│   └── pulse-admin/              # Admin CLI tool
│       ├── Cargo.toml
│       └── src/
│           ├── main.rs           # CLI (clap)
│           ├── commands/
│           │   ├── status.rs     # Show broker status
│           │   ├── topics.rs     # List topics, subscriptions
│           │   ├── dlq.rs        # Inspect/replay DLQ events
│           │   ├── services.rs   # List connected services
│           │   └── config.rs     # Validate config files
│           └── api_client.rs     # HTTP client for admin API
│
├── sdks/                         # Foreign language SDK wrappers
│   ├── python/
│   │   ├── pyproject.toml
│   │   ├── src/
│   │   │   └── lib.rs           # PyO3 bindings
│   │   ├── pulse/__init__.py    # Python package
│   │   └── tests/
│   │
│   ├── typescript/
│   │   ├── package.json
│   │   ├── src/
│   │   │   ├── native.rs        # napi-rs bindings
│   │   │   └── index.ts         # TypeScript wrapper
│   │   └── tests/
│   │
│   └── go/
│       ├── go.mod
│       ├── pulse.go             # Go wrapper over C FFI
│       └── pulse_test.go
│
├── config/                       # Example configuration files
│   ├── broker.yaml
│   ├── services.yaml
│   └── routes.yaml
│
├── tests/                        # Integration tests
│   ├── integration/
│   │   ├── publish_subscribe.rs
│   │   ├── exactly_once.rs
│   │   ├── reconnect.rs
│   │   ├── consumer_groups.rs
│   │   ├── content_filter.rs
│   │   ├── wal_recovery.rs
│   │   └── backpressure.rs
│   └── benches/
│       ├── throughput.rs         # Events/sec benchmark
│       ├── latency.rs           # P50/P99 latency benchmark
│       └── wal_write.rs         # WAL fsync benchmark
│
└── docker/
    ├── Dockerfile                # Multi-stage build for broker
    ├── Dockerfile.dev            # Dev image with tools
    └── docker-compose.yml        # Broker + example services
```

## 2. Cargo Workspace Configuration

```toml
# pulse/Cargo.toml
[workspace]
resolver = "2"
members = [
    "crates/pulse-protocol",
    "crates/pulse-broker",
    "crates/pulse-sdk",
    "crates/pulse-ffi",
    "crates/pulse-admin",
]

[workspace.package]
version = "0.1.0"
edition = "2021"
rust-version = "1.75"
license = "Apache-2.0"
repository = "https://github.com/yourorg/pulse"

[workspace.dependencies]
# Async
tokio = { version = "1", features = ["full"] }
tokio-util = { version = "0.7", features = ["codec"] }

# TLS
rustls = "0.23"
tokio-rustls = "0.26"
rustls-pemfile = "2"

# Serialization
serde = { version = "1", features = ["derive"] }
serde_json = "1"
serde_yaml = "0.9"
rmp-serde = "1"

# Storage
sled = "0.34"

# Concurrency
dashmap = "5"
arc-swap = "1"

# Protocol
uuid = { version = "1", features = ["v7"] }
crc32fast = "1"
bytes = "1"
lz4_flex = "0.11"

# Crypto
hmac = "0.12"
sha2 = "0.10"

# Observability
tracing = "0.1"
tracing-subscriber = { version = "0.3", features = ["json", "env-filter"] }
metrics = "0.22"
metrics-exporter-prometheus = "0.13"

# CLI
clap = { version = "4", features = ["derive"] }

# Error handling
thiserror = "1"
anyhow = "1"

# Testing
criterion = "0.5"
```

## 3. Crate Dependency Graph

```
pulse-protocol    (no internal deps — pure protocol logic)
       ↑
       │
  ┌────┴──────────────┐
  │                    │
pulse-sdk          pulse-broker
  │                    │
  │                    ├── depends on pulse-protocol
  ├── depends on       │
  │   pulse-protocol   │
  │                    │
pulse-ffi          pulse-admin
  │                    │
  ├── depends on       ├── HTTP client only
  │   pulse-sdk        │   (no internal deps)
  │                    │
```

**Key principle**: `pulse-protocol` has zero internal dependencies. It's shared between broker and SDK, containing only frame encoding, message types, and CRC logic. This ensures broker and SDK always agree on the wire format.

## 4. Implementation Order

### Phase 1: Foundation (Week 1-2)

```
1. pulse-protocol
   ├── types.rs         — Define all message types, enums
   ├── message_id.rs    — UUIDv7 generation
   ├── frame.rs         — Frame serialize/deserialize
   ├── crc.rs           — CRC32C helpers
   └── codec.rs         — tokio Encoder/Decoder

   Test: round-trip encode/decode for all 9 message types.

2. pulse-broker (skeleton)
   ├── main.rs           — CLI + config loading
   ├── config/           — Parse broker.yaml, services.yaml
   ├── server/listener   — TCP accept (no TLS yet)
   └── server/connection — Read/write frames (no auth yet)

   Test: broker starts, client connects, sends PUB, receives ACK (stub).
```

### Phase 2: Core Pipeline (Week 3-4)

```
3. WAL
   ├── wal_segment.rs    — Segment file format, read/write
   ├── wal.rs            — WAL writer with fsync
   └── recovery.rs       — WAL replay on startup

   Test: write events, kill process, recover, verify all events present.

4. Dedup
   ├── dedup.rs          — Bloom filter + sled

   Test: publish same msg_id twice → second returns "duplicate".

5. Pipeline integration
   ├── dispatcher.rs     — Wire ingest → dedup → WAL → ACK

   Test: end-to-end PUB → ACK with WAL durability.
```

### Phase 3: Routing & Delivery (Week 5-6)

```
6. Routing
   ├── engine.rs         — Topic trie
   ├── filter.rs         — Expression parser + evaluator
   ├── config.rs         — routes.yaml loader

   Test: wildcard matching, content filters, fan-out.

7. Delivery
   ├── manager.rs        — Per-consumer queues
   ├── ack_tracker.rs    — Track in-flight + timeout
   ├── retry.rs          — Exponential backoff
   └── dlq.rs            — Dead letter queue

   Test: publish → route → deliver → ACK. Retry on NACK. DLQ after max retries.
```

### Phase 4: Security & SDK (Week 7-8)

```
8. Authentication
   ├── TLS (rustls)
   ├── API key + HMAC verification
   └── Topic-level permissions

   Test: invalid key → reject. Publish to unauthorized topic → ERR.

9. Rust SDK
   ├── connection.rs     — Auto reconnect
   ├── publish.rs        — Retry with same msg_id
   ├── subscribe.rs      — Handler dispatch + dedup
   └── mock.rs           — MockPulse

   Test: full integration with broker. Reconnect test. Dedup test.
```

### Phase 5: Polish (Week 9-10)

```
10. Namespace isolation
11. Consumer groups
12. Content-based filtering (SUB filter)
13. Transform pipeline
14. Backpressure (FLOW frame)
15. WAL compaction
16. Metrics + Prometheus exporter
17. Admin CLI
18. Hot config reload
19. Docker packaging
20. Benchmarks
```

## 5. Build & Test Commands

```bash
# Build everything
cargo build --workspace

# Build broker only (release)
cargo build --release -p pulse-broker

# Run all tests
cargo test --workspace

# Run specific crate tests
cargo test -p pulse-protocol
cargo test -p pulse-broker

# Run integration tests (requires broker)
cargo test --test '*' -- --test-threads=1

# Benchmarks
cargo bench -p pulse-broker

# Clippy (CI enforced)
cargo clippy --workspace -- -D warnings

# Format check
cargo fmt --all -- --check

# Build Docker image
docker build -f docker/Dockerfile -t pulse-broker:latest .
```

## 6. Docker

### Dockerfile (multi-stage)

```dockerfile
# Build stage
FROM rust:1.75-slim AS builder
WORKDIR /build
COPY . .
RUN cargo build --release -p pulse-broker

# Runtime stage
FROM debian:bookworm-slim
RUN apt-get update && apt-get install -y ca-certificates && rm -rf /var/lib/apt/lists/*
COPY --from=builder /build/target/release/pulse-broker /usr/local/bin/
COPY config/ /etc/pulse/
EXPOSE 4222 9090 8080
VOLUME /var/lib/pulse
CMD ["pulse-broker", "--config", "/etc/pulse/broker.yaml"]
```

### docker-compose.yml (development)

```yaml
version: "3.8"
services:
  broker:
    build:
      context: .
      dockerfile: docker/Dockerfile.dev
    ports:
      - "4222:4222"   # Pulse protocol
      - "9090:9090"   # Metrics
      - "8080:8080"   # Health + Admin API
    volumes:
      - pulse-data:/var/lib/pulse
      - ./config:/etc/pulse

  prometheus:
    image: prom/prometheus:latest
    ports:
      - "9091:9090"
    volumes:
      - ./config/prometheus.yml:/etc/prometheus/prometheus.yml

  grafana:
    image: grafana/grafana:latest
    ports:
      - "3000:3000"
    volumes:
      - ./config/grafana/:/etc/grafana/provisioning/

volumes:
  pulse-data:
```
