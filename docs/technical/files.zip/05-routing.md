# Routing Pipeline Design

## 1. Overview

The routing pipeline determines which consumers receive which events. It evaluates in order:

```
Event arrives
  │
  ▼
┌──────────────┐     ┌───────────────┐     ┌─────────────┐     ┌──────────┐
│ Topic Match  │────>│ Content Filter │────>│  Transform  │────>│ Fan-out  │
│              │     │  (optional)    │     │ (optional)  │     │          │
└──────────────┘     └───────────────┘     └─────────────┘     └──────────┘
```

## 2. Topic Matching

### 2.1 Subscription-Based Matching

Every SUB frame registers a topic pattern. The routing engine maintains a concurrent map:

```rust
type RoutingTable = DashMap<TopicPattern, Vec<SubscriptionTarget>>;

pub struct SubscriptionTarget {
    pub consumer_id: ConsumerId,
    pub sub_id: SubId,
    pub group: Option<String>,         // consumer group name
    pub filter: Option<CompiledFilter>, // content-based filter
    pub deliver_tx: mpsc::Sender<DeliveryEvent>,
}
```

### 2.2 Wildcard Matching Algorithm

Three levels of matching, checked in priority order:

| Pattern | Matches | Example |
|---------|---------|---------|
| Exact: `order.created` | Only `order.created` | `order.created` ✓, `order.updated` ✗ |
| Single wildcard: `order.*` | Any single segment after `order.` | `order.created` ✓, `order.us.created` ✗ |
| Multi wildcard: `order.>` | One or more segments after `order.` | `order.created` ✓, `order.us.created` ✓ |
| Global: `*` | All topics | Everything ✓ |

**Implementation**: trie-based lookup for O(segments) matching:

```rust
pub struct TopicTrie {
    exact: HashMap<String, Vec<SubscriptionTarget>>,
    children: HashMap<String, TopicTrie>,
    single_wildcard: Vec<SubscriptionTarget>,    // "*" at this level
    multi_wildcard: Vec<SubscriptionTarget>,      // ">" at this level
}

impl TopicTrie {
    pub fn resolve(&self, topic: &str) -> Vec<&SubscriptionTarget> {
        let segments: Vec<&str> = topic.split('.').collect();
        let mut results = Vec::new();
        self.resolve_recursive(&segments, 0, &mut results);
        results
    }

    fn resolve_recursive(
        &self,
        segments: &[&str],
        depth: usize,
        results: &mut Vec<&SubscriptionTarget>,
    ) {
        // Multi-wildcard matches everything from here down
        results.extend(&self.multi_wildcard);

        if depth >= segments.len() {
            // Exact match at this depth
            if let Some(targets) = self.exact.get("") {
                results.extend(targets);
            }
            return;
        }

        let segment = segments[depth];

        // Single wildcard: matches this segment, continue to next
        if !self.single_wildcard.is_empty() && depth == segments.len() - 1 {
            results.extend(&self.single_wildcard);
        }

        // Exact segment match: descend
        if let Some(child) = self.children.get(segment) {
            child.resolve_recursive(segments, depth + 1, results);
        }
    }
}
```

### 2.3 Consumer Groups

When multiple consumers subscribe with the same `group` name, each event is delivered to exactly ONE member of the group (load balancing):

```
SUB: { topic: "order.created", group: "payment-processors" }
  → Service payment-1 subscribes
  → Service payment-2 subscribes
  → Service payment-3 subscribes

Event "order.created" arrives:
  → Router finds group "payment-processors" has 3 members
  → Select one via round-robin (or least-loaded)
  → Deliver to ONLY that member

If that member NACKs or times out:
  → Retry to SAME member first (preserve ordering)
  → After 2 consecutive failures: rebalance to another group member
```

**Implementation**:

```rust
pub struct ConsumerGroup {
    name: String,
    members: Vec<SubscriptionTarget>,
    next_index: AtomicU64,  // round-robin counter
}

impl ConsumerGroup {
    pub fn select(&self) -> &SubscriptionTarget {
        let idx = self.next_index.fetch_add(1, Ordering::Relaxed);
        &self.members[idx as usize % self.members.len()]
    }
}
```

## 3. Content-Based Filtering

### 3.1 Filter Expression Language

Filters operate on the deserialized event payload. Syntax:

```
Expression = Comparison | Logic | Function

Comparison:
  payload.field.nested > 1000
  payload.status == "active"
  payload.tags != null

Logic:
  expr AND expr
  expr OR expr
  NOT expr
  (expr)

Functions:
  contains(payload.name, "test")
  starts_with(payload.region, "VN")
  ends_with(payload.email, "@company.com")
  len(payload.items) > 5
  in(payload.status, ["active", "pending"])

Operators:
  ==  !=  >  <  >=  <=

Types:
  String:  "hello"
  Number:  42, 3.14
  Bool:    true, false
  Null:    null
  Array:   ["a", "b"]  (only in `in()` function)
```

### 3.2 Filter Compilation

Filters in SUB frames and routes.yaml are compiled once into an AST at registration time, then evaluated per-event:

```rust
pub enum FilterExpr {
    Compare {
        left: FieldPath,       // e.g., "payload.amount"
        op: CompareOp,         // Gt, Lt, Eq, Neq, Gte, Lte
        right: Value,          // literal value
    },
    Logic {
        op: LogicOp,           // And, Or
        left: Box<FilterExpr>,
        right: Box<FilterExpr>,
    },
    Not(Box<FilterExpr>),
    Function {
        name: FunctionName,    // Contains, StartsWith, EndsWith, Len, In
        args: Vec<FilterArg>,
    },
}

pub struct CompiledFilter {
    ast: FilterExpr,
}

impl CompiledFilter {
    pub fn evaluate(&self, payload: &msgpack::Value) -> bool {
        self.eval_expr(&self.ast, payload)
    }

    fn eval_expr(&self, expr: &FilterExpr, payload: &msgpack::Value) -> bool {
        match expr {
            FilterExpr::Compare { left, op, right } => {
                let field_value = self.resolve_path(left, payload);
                self.compare(field_value, op, right)
            }
            FilterExpr::Logic { op, left, right } => {
                match op {
                    LogicOp::And => self.eval_expr(left, payload) && self.eval_expr(right, payload),
                    LogicOp::Or => self.eval_expr(left, payload) || self.eval_expr(right, payload),
                }
            }
            FilterExpr::Not(inner) => !self.eval_expr(inner, payload),
            FilterExpr::Function { name, args } => self.eval_function(name, args, payload),
        }
    }
}
```

### 3.3 Filter Performance

- Filter compilation: ~1μs (done once at SUB time)
- Filter evaluation: ~1-10μs per event (depends on expression complexity)
- Field path resolution: uses MessagePack in-place traversal (no full deserialization)

## 4. Transform Pipeline

### 4.1 Transform Operations

Transforms modify the event payload before delivery. Defined in routes.yaml:

```yaml
transform:
  - set: "payload.warehouse = 'hanoi-wh-01'"      # add/overwrite field
  - remove: "payload.customer.credit_card"          # remove sensitive field
  - rename: "payload.old_name -> payload.new_name"  # rename field
  - copy: "payload.id -> headers.order_id"          # copy value to headers
  - default: "payload.priority = 'normal'"           # set only if field missing
```

### 4.2 Transform Implementation

```rust
pub enum TransformOp {
    Set { path: FieldPath, value: Value },
    Remove { path: FieldPath },
    Rename { from: FieldPath, to: FieldPath },
    Copy { from: FieldPath, to: FieldPath },
    Default { path: FieldPath, value: Value },
}

pub struct TransformPipeline {
    ops: Vec<TransformOp>,
}

impl TransformPipeline {
    /// Apply transforms to a CLONE of the payload.
    /// Original event in WAL is never modified.
    pub fn apply(&self, payload: &mut msgpack::Value) {
        for op in &self.ops {
            match op {
                TransformOp::Set { path, value } => {
                    set_field(payload, path, value.clone());
                }
                TransformOp::Remove { path } => {
                    remove_field(payload, path);
                }
                TransformOp::Rename { from, to } => {
                    if let Some(val) = remove_field(payload, from) {
                        set_field(payload, to, val);
                    }
                }
                TransformOp::Copy { from, to } => {
                    if let Some(val) = get_field(payload, from) {
                        set_field(payload, to, val.clone());
                    }
                }
                TransformOp::Default { path, value } => {
                    if get_field(payload, path).is_none() {
                        set_field(payload, path, value.clone());
                    }
                }
            }
        }
    }
}
```

**Important**: transforms operate on a clone of the payload. The original event stored in WAL is immutable. Different consumers may receive different transformed payloads from the same event.

## 5. Route Configuration (routes.yaml)

### 5.1 Full Configuration Reference

```yaml
routes:
  # Simple topic subscription — mostly handled by SUB frames.
  # Routes in YAML are for broker-side logic that doesn't depend on consumers.

  # ─── Content-based routing ───
  - name: "large-orders-fraud-check"
    description: "Route orders > $1000 to fraud detection"
    match:
      topic: "order.created"
      where: "payload.amount > 1000"
    deliver:
      - service: "fraud-detection"
    enabled: true

  # ─── Transform + filter ───
  - name: "order-to-warehouse-vn"
    match:
      topic: "order.created"
      where: "payload.region == 'VN'"
    transform:
      - set: "payload.warehouse = 'hanoi-wh-01'"
      - remove: "payload.customer.credit_card"
      - remove: "payload.customer.phone"
    deliver:
      - service: "vn-warehouse"

  # ─── Wildcard fan-out ───
  - name: "all-events-to-analytics"
    match:
      topic: "*"
    deliver:
      - service: "analytics"
        mode: "best-effort"    # no retry on failure

  # ─── Multi-target ───
  - name: "payment-notifications"
    match:
      topic: "payment.completed"
    deliver:
      - service: "email-service"
      - service: "sms-service"
        where: "payload.amount > 5000"   # per-target filter
      - service: "accounting-service"

  # ─── Consumer group ───
  - name: "order-processing-pool"
    match:
      topic: "order.created"
    deliver:
      - group: "order-processors"
        balance: "round-robin"            # or "least-loaded"

# ─── DLQ / failure handling ───
failure_policy:
  default:
    max_retries: 5
    backoff:
      type: "exponential"
      initial_secs: 1
      max_secs: 60
      multiplier: 2.0
    dead_letter:
      topic_prefix: "dlq"                # events go to "dlq.{original_topic}"
      retention_hours: 168                # 7 days
    alert:
      webhook: "https://hooks.slack.com/services/T.../B.../xxx"
      on: ["dlq"]                         # alert when event enters DLQ

  overrides:
    - match_topic: "payment.*"
      max_retries: 10                     # more retries for payments
      alert:
        on: ["dlq", "retry_3"]           # also alert on 3rd retry
```

### 5.2 Hot Reload

```
File watcher (inotify) on routes.yaml
  │
  ▼
Parse new YAML
  │
  ├── Syntax error → log error, keep old config, emit metric
  │
  ├── Semantic error (unknown service, invalid filter) → same
  │
  └── Valid → 
        1. Compile all new filter expressions
        2. Build new RoutingConfig struct
        3. ArcSwap::store(new_config)
        4. Log: "Routes reloaded: 5 rules active"
        5. Emit metric: pulse_config_reload_total{status="success"}

In-flight events: processed with the config that was active when they entered the pipeline. No mid-event config switch.
```

## 6. Routing Resolution Algorithm

When an event enters the routing stage:

```rust
pub fn resolve(&self, topic: &str, payload: &Value) -> Vec<DeliveryTarget> {
    let mut targets = Vec::new();

    // 1. Subscription-based targets (from SUB frames)
    let sub_targets = self.trie.resolve(topic);
    for target in sub_targets {
        // Apply per-subscription content filter
        if let Some(filter) = &target.filter {
            if !filter.evaluate(payload) {
                continue; // filtered out
            }
        }
        targets.push(target.to_delivery_target());
    }

    // 2. Route-config targets (from routes.yaml)
    for route in self.config.load().routes.iter() {
        if !route.enabled { continue; }

        // Topic match
        if !route.match_topic.matches(topic) { continue; }

        // Content filter
        if let Some(filter) = &route.compiled_filter {
            if !filter.evaluate(payload) { continue; }
        }

        // Apply transforms (clone payload)
        let mut transformed_payload = payload.clone();
        if let Some(pipeline) = &route.transform {
            pipeline.apply(&mut transformed_payload);
        }

        // Add delivery targets
        for deliver in &route.deliver {
            // Per-target filter
            if let Some(target_filter) = &deliver.compiled_filter {
                if !target_filter.evaluate(payload) { continue; }
            }

            targets.push(DeliveryTarget {
                consumer_id: deliver.service.clone(),
                group: deliver.group.clone(),
                payload: transformed_payload.clone(),
                mode: deliver.mode,
            });
        }
    }

    // 3. Deduplicate targets (same consumer shouldn't receive twice)
    targets.dedup_by_key(|t| t.consumer_id.clone());

    // 4. Handle consumer groups — pick one member per group
    self.resolve_groups(&mut targets);

    targets
}
```

## 7. Unrouted Events

If an event matches no subscription and no route:

```yaml
# broker.yaml
unrouted_policy: "log"    # "log" | "reject" | "store"

# "log":    WAL stores event, log warning, no delivery. Event stays in WAL until compacted.
# "reject": Send ERR to publisher. Event NOT written to WAL.
# "store":  WAL stores, tag as unrouted. Queryable via admin API.
#           If a matching subscription arrives later, event is NOT retroactively delivered.
```

Default: `"log"` — safest option. Event is durable (if a subscription appears during the event's buffer window, it may be deliverable).

## 8. Performance Expectations

| Operation | Complexity | Latency |
|-----------|-----------|---------|
| Topic trie lookup | O(number of topic segments) | <1μs |
| Content filter evaluation | O(expression depth × field depth) | 1-10μs |
| Transform pipeline | O(number of ops) | 1-5μs |
| Full route resolution (typical) | — | 5-20μs |
| Route config reload | O(number of rules × compilation) | 1-10ms (background) |

At 10 events/sec, routing adds negligible overhead.
