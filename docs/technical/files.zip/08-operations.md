# Operations & Observability

## 1. Deployment

### 1.1 System Requirements

| Resource | Minimum | Recommended | Notes |
|----------|---------|-------------|-------|
| CPU | 1 core | 2 cores | tokio uses all available cores |
| RAM | 512 MB | 2 GB | Depends on buffer size + connections |
| Disk | 1 GB SSD | 10 GB SSD | WAL + sled. HDD not recommended (fsync latency) |
| OS | Linux 5.4+ | Ubuntu 22.04+ | Also works on macOS for dev |
| Network | 10 Mbps | 100 Mbps | Per-event overhead: ~200 bytes + payload |

### 1.2 Installation

```bash
# Option 1: Binary download
curl -fsSL https://github.com/yourorg/pulse/releases/latest/download/pulse-broker-linux-amd64 \
  -o /usr/local/bin/pulse-broker
chmod +x /usr/local/bin/pulse-broker

# Option 2: Docker
docker run -d \
  --name pulse \
  -p 4222:4222 \
  -p 9090:9090 \
  -p 8080:8080 \
  -v /var/lib/pulse:/var/lib/pulse \
  -v /etc/pulse:/etc/pulse \
  ghcr.io/yourorg/pulse-broker:latest

# Option 3: systemd service
cat > /etc/systemd/system/pulse-broker.service << 'EOF'
[Unit]
Description=Pulse Event Broker
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=pulse
Group=pulse
ExecStart=/usr/local/bin/pulse-broker --config /etc/pulse/broker.yaml
Restart=always
RestartSec=5
LimitNOFILE=65536

# Security hardening
NoNewPrivileges=yes
ProtectSystem=strict
ProtectHome=yes
ReadWritePaths=/var/lib/pulse /var/log/pulse

[Install]
WantedBy=multi-user.target
EOF

systemctl enable --now pulse-broker
```

### 1.3 TLS Setup

```bash
# Using Let's Encrypt (recommended for internet-facing)
certbot certonly --standalone -d pulse.company.com
# Cert: /etc/letsencrypt/live/pulse.company.com/fullchain.pem
# Key:  /etc/letsencrypt/live/pulse.company.com/privkey.pem

# Self-signed (dev/internal only)
openssl req -x509 -newkey rsa:4096 -nodes \
  -keyout /etc/pulse/key.pem \
  -out /etc/pulse/cert.pem \
  -days 365 -subj '/CN=pulse.internal'
```

Update `broker.yaml`:

```yaml
tls:
  cert_path: "/etc/letsencrypt/live/pulse.company.com/fullchain.pem"
  key_path: "/etc/letsencrypt/live/pulse.company.com/privkey.pem"
```

Broker watches cert files and auto-reloads on change (supports certbot auto-renewal).

## 2. Health Checks

### 2.1 Endpoints

```
GET /health     → 200 OK if broker process is running
GET /ready      → 200 OK if broker is accepting connections
                   503 if shutting down or recovering
GET /status     → JSON with detailed status
```

**`/status` response:**

```json
{
  "broker_id": "pulse-broker-01",
  "version": "0.1.0",
  "uptime_secs": 86400,
  "state": "running",
  "connections": {
    "active": 12,
    "max": 5000
  },
  "namespaces": ["ecommerce", "internal-tools"],
  "wal": {
    "active_segment": 42,
    "total_segments": 5,
    "total_size_bytes": 134217728,
    "pending_events": 23
  },
  "delivery": {
    "in_flight": 5,
    "total_delivered": 1234567,
    "total_acked": 1234560,
    "dlq_count": 7
  }
}
```

### 2.2 Kubernetes Probes

```yaml
# Deployment snippet
containers:
  - name: pulse-broker
    livenessProbe:
      httpGet:
        path: /health
        port: 8080
      initialDelaySeconds: 5
      periodSeconds: 10
    readinessProbe:
      httpGet:
        path: /ready
        port: 8080
      initialDelaySeconds: 10
      periodSeconds: 5
    startupProbe:
      httpGet:
        path: /ready
        port: 8080
      failureThreshold: 30
      periodSeconds: 2
```

## 3. Metrics (Prometheus)

### 3.1 Exposed Metrics

All metrics prefixed with `pulse_`.

**Connection metrics:**

| Metric | Type | Description |
|--------|------|-------------|
| `pulse_connections_active` | Gauge | Currently connected clients |
| `pulse_connections_total` | Counter | Total connections since start |
| `pulse_auth_failures_total` | Counter | Failed authentication attempts |
| `pulse_auth_failures_total{reason="..."}` | Counter | By reason: invalid_key, expired_hmac, forbidden |

**Event metrics:**

| Metric | Type | Description |
|--------|------|-------------|
| `pulse_events_received_total` | Counter | PUB frames received |
| `pulse_events_stored_total` | Counter | Events written to WAL |
| `pulse_events_delivered_total` | Counter | Events sent to consumers |
| `pulse_events_acked_total` | Counter | Consumer ACKs received |
| `pulse_events_nacked_total` | Counter | Consumer NACKs received |
| `pulse_events_dlq_total` | Counter | Events moved to DLQ |
| `pulse_events_dedup_total` | Counter | Duplicate events detected |

**Latency metrics:**

| Metric | Type | Description |
|--------|------|-------------|
| `pulse_publish_latency_seconds` | Histogram | PUB → ACK(stored) latency |
| `pulse_delivery_latency_seconds` | Histogram | Stored → delivered to consumer |
| `pulse_end_to_end_latency_seconds` | Histogram | PUB → consumer ACK(done) |
| `pulse_wal_write_latency_seconds` | Histogram | WAL append + fsync time |

**Queue metrics:**

| Metric | Type | Description |
|--------|------|-------------|
| `pulse_consumer_queue_depth{consumer="..."}` | Gauge | Pending events per consumer |
| `pulse_consumer_inflight{consumer="..."}` | Gauge | In-flight (delivered, awaiting ACK) |
| `pulse_consumer_overflow{consumer="..."}` | Gauge | Events in disk overflow |
| `pulse_retry_queue_depth` | Gauge | Events waiting for retry |

**WAL metrics:**

| Metric | Type | Description |
|--------|------|-------------|
| `pulse_wal_segments_active` | Gauge | Number of WAL segments |
| `pulse_wal_size_bytes` | Gauge | Total WAL disk usage |
| `pulse_wal_writes_total` | Counter | WAL write operations |
| `pulse_wal_compactions_total` | Counter | Compaction runs |
| `pulse_wal_recovery_duration_seconds` | Gauge | Last recovery time |

**System metrics:**

| Metric | Type | Description |
|--------|------|-------------|
| `pulse_config_reload_total{status="success|error"}` | Counter | Config hot-reload events |
| `pulse_uptime_seconds` | Gauge | Broker uptime |

### 3.2 Prometheus Configuration

```yaml
# prometheus.yml
scrape_configs:
  - job_name: 'pulse-broker'
    static_configs:
      - targets: ['broker:9090']
    scrape_interval: 15s
```

### 3.3 Recommended Alerts

```yaml
# alerts.yml (Prometheus AlertManager)
groups:
  - name: pulse
    rules:
      # DLQ growing — events failing permanently
      - alert: PulseDlqGrowing
        expr: rate(pulse_events_dlq_total[5m]) > 0
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "Events entering DLQ"
          description: "{{ $value }} events/sec entering dead letter queue"

      # Consumer queue backing up
      - alert: PulseConsumerQueueHigh
        expr: pulse_consumer_queue_depth > 5000
        for: 10m
        labels:
          severity: warning
        annotations:
          summary: "Consumer {{ $labels.consumer }} queue depth: {{ $value }}"

      # High publish latency
      - alert: PulsePublishLatencyHigh
        expr: histogram_quantile(0.99, rate(pulse_publish_latency_seconds_bucket[5m])) > 0.1
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "P99 publish latency > 100ms"

      # WAL disk usage
      - alert: PulseWalDiskHigh
        expr: pulse_wal_size_bytes > 5e9  # 5 GB
        labels:
          severity: warning
        annotations:
          summary: "WAL disk usage: {{ $value | humanize1024 }}"

      # No connections (broker might be unreachable)
      - alert: PulseNoConnections
        expr: pulse_connections_active == 0
        for: 5m
        labels:
          severity: critical
        annotations:
          summary: "No active connections to Pulse broker"

      # Broker down
      - alert: PulseBrokerDown
        expr: up{job="pulse-broker"} == 0
        for: 1m
        labels:
          severity: critical
        annotations:
          summary: "Pulse broker is down"
```

## 4. Logging

### 4.1 Structured Logging Format

```json
{
  "timestamp": "2024-01-15T10:30:00.000Z",
  "level": "INFO",
  "target": "pulse_broker::pipeline::dispatcher",
  "message": "Event stored",
  "msg_id": "01945a2b-3c4d-7e5f-8a9b-c0d1e2f3a4b5",
  "topic": "order.created",
  "namespace": "ecommerce",
  "publisher": "order-service",
  "wal_segment": 42,
  "wal_offset": 1048576,
  "latency_us": 1234
}
```

### 4.2 Log Levels

| Level | Usage |
|-------|-------|
| ERROR | Unrecoverable: WAL write failure, sled corruption, bind failure |
| WARN | Recoverable: consumer NACK, auth failure, dedup collision, DLQ entry |
| INFO | Operational: connection open/close, config reload, compaction |
| DEBUG | Diagnostic: individual frame processing, routing decisions |
| TRACE | Wire-level: raw frame bytes, CRC details |

### 4.3 Configuration

```yaml
# broker.yaml
logging:
  level: "info"                    # global default
  format: "json"                   # "json" | "pretty" (dev)
  output: "stdout"                 # "stdout" | "file"
  file_path: "/var/log/pulse/broker.log"  # if output: "file"
  file_rotation: "daily"
  file_max_size_mb: 100
  file_max_backups: 7

  # Per-module overrides
  overrides:
    pulse_broker::pipeline: "debug"
    pulse_broker::server::connection: "warn"
```

Or via environment:

```bash
RUST_LOG="info,pulse_broker::pipeline=debug" pulse-broker
```

## 5. Admin API

HTTP API on the health port (8080) for operational tasks.

### 5.1 Endpoints

```
# Status
GET  /api/v1/status                     → Broker status (same as /status)

# Topics
GET  /api/v1/topics                     → List all active topics
GET  /api/v1/topics/{topic}/subscribers → List subscribers for a topic

# Services
GET  /api/v1/services                   → List connected services
GET  /api/v1/services/{id}              → Service detail (subscriptions, queue depth)

# DLQ
GET  /api/v1/dlq                        → List DLQ events (paginated)
GET  /api/v1/dlq/{msg_id}               → DLQ event detail
POST /api/v1/dlq/{msg_id}/replay        → Re-inject event into original topic
POST /api/v1/dlq/replay-all             → Replay all DLQ events
DELETE /api/v1/dlq/{msg_id}             → Purge single DLQ event
DELETE /api/v1/dlq                      → Purge all DLQ events

# Config
POST /api/v1/config/reload              → Force config reload
GET  /api/v1/config/validate            → Validate current config files

# WAL
GET  /api/v1/wal/status                 → WAL segments, sizes, pending count
POST /api/v1/wal/compact                → Trigger manual compaction
```

### 5.2 Admin CLI

```bash
# Status
pulse-admin status --broker broker:8080

# List topics
pulse-admin topics list

# Inspect DLQ
pulse-admin dlq list --limit 20
pulse-admin dlq show <msg_id>
pulse-admin dlq replay <msg_id>
pulse-admin dlq replay-all --topic "order.created"
pulse-admin dlq purge --older-than 7d

# Service info
pulse-admin services list
pulse-admin services show order-service

# Config validation
pulse-admin config validate ./config/

# Force compaction
pulse-admin wal compact
```

## 6. Troubleshooting

### 6.1 Common Issues

**Publisher gets Timeout error**

```
Check:
1. Broker is reachable? → pulse-admin status
2. WAL disk full?       → pulse-admin wal status → check disk space
3. Network latency?     → ping broker host
4. Broker overloaded?   → check pulse_publish_latency_seconds metric

Fix:
- Increase publish_timeout in SDK config
- If WAL disk full: increase disk, run compaction, reduce retention
- If broker CPU high: check for hot consumer (slow handler causing retry storms)
```

**Consumer not receiving events**

```
Check:
1. Consumer connected?  → pulse-admin services show <consumer_id>
2. Subscription active? → pulse-admin topics <topic> subscribers
3. Filter too strict?   → check filter expression in SUB or routes.yaml
4. Consumer group?      → another group member may be receiving

Fix:
- Verify topic name matches exactly (including namespace)
- Test filter with simpler expression
- Check consumer logs for deserialization errors
```

**DLQ accumulating events**

```
Check:
1. What errors?          → pulse-admin dlq list → inspect last_error
2. Consumer healthy?     → check consumer logs
3. Payload changed?      → schema mismatch between publisher and consumer

Fix:
- Fix consumer handler bug → pulse-admin dlq replay-all
- If schema issue: update consumer, then replay
- If events are stale/irrelevant: pulse-admin dlq purge
```

**High memory usage**

```
Check:
1. Ring buffer size?     → config: buffer_capacity
2. Consumer queue depth? → pulse_consumer_queue_depth metric
3. Many offline consumers holding queues?

Fix:
- Reduce ring_buffer capacity in broker.yaml
- Investigate slow/offline consumers
- Lower max_pending_per_consumer
- Set stricter retention on consumer queues
```

**WAL growing too large**

```
Check:
1. Compaction running?   → pulse_wal_compactions_total metric
2. Pending events?       → pulse-admin wal status → pending count
3. Consumers keeping events pending?

Fix:
- Force compaction: pulse-admin wal compact
- Investigate consumers holding events (slow/offline)
- Reduce retention_hours
- Increase compaction frequency (compaction.interval_secs)
```

### 6.2 Debug Mode

For deep investigation, enable trace logging for specific modules:

```bash
RUST_LOG="pulse_broker::pipeline=trace,pulse_broker::delivery=debug" pulse-broker

# This logs every frame, every routing decision, every ACK
# WARNING: extremely verbose. Use only for short debugging sessions.
```

## 7. Backup & Disaster Recovery

### 7.1 What to Back Up

| Data | Location | Method | Frequency |
|------|----------|--------|-----------|
| WAL segments | `/var/lib/pulse/wal/` | Filesystem snapshot or rsync | Continuous or hourly |
| State DB | `/var/lib/pulse/state/` | sled export or filesystem copy | Hourly |
| Config | `/etc/pulse/` | Version control (git) | On every change |

### 7.2 Recovery Procedure

```bash
# Full recovery from backup
1. Stop broker
2. Restore WAL segments to /var/lib/pulse/wal/
3. Restore state DB to /var/lib/pulse/state/
4. Restore config to /etc/pulse/
5. Start broker
   → Broker automatically replays WAL and recovers pending events
```

**Important**: WAL replay handles inconsistency between WAL and state DB. If state DB is older than WAL, replay will re-process missing events. This is safe because all operations are idempotent.

## 8. Security Checklist

```
[ ] TLS enabled with valid certificate
[ ] API keys generated with sufficient entropy (32+ bytes)
[ ] services.yaml has minimal permissions per service
[ ] Admin API bound to internal network only (not 0.0.0.0)
[ ] Metrics endpoint bound to internal network
[ ] Firewall: port 4222 open only to known service IPs
[ ] Firewall: ports 8080, 9090 open only to monitoring infra
[ ] Config files readable only by pulse user (chmod 600)
[ ] API keys not committed to version control
[ ] Log level set to INFO (not DEBUG/TRACE in production)
[ ] HMAC timestamp validation enabled (anti-replay)
```
