# WAL & Storage Design

## 1. Storage Architecture Overview

```
/var/lib/pulse/
├── wal/                        # Write-Ahead Log segments
│   ├── segment-000001.wal      # 64 MB max per segment
│   ├── segment-000002.wal
│   └── segment-000003.wal      # active (currently being written)
│
├── state/                      # sled embedded database
│   └── (sled internal files)   # event state, dedup index, consumer offsets
│
├── overflow/                   # disk-backed consumer queue overflow
│   ├── consumer-order-svc/
│   └── consumer-payment-svc/
│
└── archive/                    # compressed old segments (optional)
    └── segment-000001.wal.zst
```

## 2. Write-Ahead Log (WAL)

### 2.1 Purpose

The WAL is the source of truth for event durability. Every event must be written to WAL and fsynced before the broker sends ACK STORED to the publisher. On crash recovery, the WAL is replayed to reconstruct in-flight state.

### 2.2 Segment File Format

Each segment is an append-only file with sequential records:

```
Segment File Layout:
┌──────────────────────────────────────────────┐
│ Segment Header (32 bytes)                     │
├──────────────────────────────────────────────┤
│ Record 0                                      │
├──────────────────────────────────────────────┤
│ Record 1                                      │
├──────────────────────────────────────────────┤
│ ...                                           │
├──────────────────────────────────────────────┤
│ Record N                                      │
└──────────────────────────────────────────────┘
```

**Segment Header:**

```
Offset  Size  Field
0       4     Magic: 0x50_4C_57_4C ("PLWL" = Pulse WAL)
4       1     Version: 0x01
5       4     Segment Number (uint32)
9       8     Created At (uint64, millis since epoch)
17      15    Reserved (zeros)
```

**Record Format:**

```
Offset  Size      Field
0       4         Record Length (uint32, total bytes including this field)
4       1         Record Type
5       16        Message ID (UUIDv7)
21      variable  Record Data (depends on type)
-4      4         CRC32C over bytes [0, len-4)
```

**Record Types:**

| Type | Value | Data Contents | Description |
|------|-------|---------------|-------------|
| EVENT_WRITE | 0x01 | Full serialized event (topic + payload + headers) | Event ingested and stored |
| COMPLETION | 0x02 | Consumer ID (string) | Consumer acknowledged processing |
| BATCH_WRITE | 0x03 | Array of events (same as PUB batch) | Atomic batch write |
| BATCH_COMPLETION | 0x04 | Batch ID + Consumer ID | Entire batch completed |
| CHECKPOINT | 0x05 | Snapshot of pending event IDs | Optimization for faster recovery |

### 2.3 Write Path

```rust
pub struct WalWriter {
    active_segment: File,
    segment_number: u32,
    segment_offset: u64,
    segment_max_size: u64,       // 64 MB default
    write_buffer: Vec<u8>,       // reusable buffer to avoid allocs
}

impl WalWriter {
    pub async fn append(&mut self, event: &Event) -> Result<WalPosition> {
        // 1. Serialize record
        let record = WalRecord::event_write(event);
        let bytes = record.serialize(&mut self.write_buffer);

        // 2. Check segment rotation
        if self.segment_offset + bytes.len() as u64 > self.segment_max_size {
            self.rotate_segment().await?;
        }

        // 3. Write to file
        let position = WalPosition {
            segment: self.segment_number,
            offset: self.segment_offset,
        };
        self.active_segment.write_all(bytes).await?;

        // 4. fsync — THIS IS THE DURABILITY BOUNDARY
        self.active_segment.sync_data().await?;

        // 5. Update offset
        self.segment_offset += bytes.len() as u64;

        Ok(position)
    }

    async fn rotate_segment(&mut self) -> Result<()> {
        // Sync current segment
        self.active_segment.sync_all().await?;

        // Create new segment
        self.segment_number += 1;
        let path = format!("wal/segment-{:06}.wal", self.segment_number);
        self.active_segment = File::create(&path).await?;

        // Write segment header
        let header = SegmentHeader::new(self.segment_number);
        self.active_segment.write_all(&header.serialize()).await?;
        self.segment_offset = 32; // header size

        Ok(())
    }
}
```

### 2.4 fsync Strategy

| Mode | Config value | Behavior | Durability | Performance |
|------|-------------|----------|------------|-------------|
| fsync | `"fsync"` | `File::sync_all()` after each write | Highest — metadata + data flushed | ~1-5ms per write |
| fdatasync | `"fdatasync"` | `File::sync_data()` after each write | High — data flushed, metadata lazy | ~0.5-2ms per write |
| none | `"none"` | No explicit sync (OS page cache) | Low — up to 30s of data loss on crash | ~0.01ms per write |

**Recommendation**: Use `"fsync"` in production. With 10 events/sec, fsync overhead is negligible. Use `"none"` only in testing/development.

**Batched fsync optimization**: If multiple PUB frames arrive within 1ms, accumulate them and fsync once. This amortizes fsync cost under high throughput.

```rust
// Group commit: collect writes for up to 1ms, then single fsync
pub struct GroupCommitWriter {
    pending: Vec<(Event, oneshot::Sender<Result<WalPosition>>)>,
    flush_interval: Duration,  // 1ms
}

impl GroupCommitWriter {
    async fn run(&mut self) {
        loop {
            // Collect pending writes
            let deadline = Instant::now() + self.flush_interval;
            while Instant::now() < deadline {
                if let Ok(item) = self.rx.try_recv() {
                    self.pending.push(item);
                }
                if self.pending.len() >= 100 { break; } // batch size cap
                tokio::task::yield_now().await;
            }

            if self.pending.is_empty() { continue; }

            // Write all, single fsync
            let positions = Vec::new();
            for (event, _) in &self.pending {
                let pos = self.wal.write_no_sync(event).await?;
                positions.push(pos);
            }
            self.wal.fsync().await?;

            // Notify all waiters
            for ((_, tx), pos) in self.pending.drain(..).zip(positions) {
                let _ = tx.send(Ok(pos));
            }
        }
    }
}
```

## 3. Crash Recovery

### 3.1 Recovery Algorithm

```
fn recover(data_dir: &Path) -> BrokerState {
    let segments = list_wal_segments(data_dir.join("wal"))
        .sort_by_segment_number();

    let mut written: HashMap<MessageId, Event> = HashMap::new();
    let mut completed: HashSet<(MessageId, ConsumerId)> = HashSet::new();

    for segment in &segments {
        let mut reader = SegmentReader::open(segment)?;

        loop {
            match reader.next_record() {
                Ok(Record::EventWrite { msg_id, event }) => {
                    written.insert(msg_id, event);
                }
                Ok(Record::Completion { msg_id, consumer_id }) => {
                    completed.insert((msg_id, consumer_id));
                }
                Ok(Record::Checkpoint { pending_ids }) => {
                    // Optimization: only process events in pending_ids
                    // Skip events that were already completed before checkpoint
                }
                Ok(Record::BatchWrite { batch_id, events }) => {
                    for event in events {
                        written.insert(event.msg_id, event);
                    }
                }
                Err(WalError::CorruptRecord) => {
                    // Truncate segment at this point
                    // All subsequent records in this segment are lost
                    // (they were never ACKed, so publisher will retry)
                    truncate_at_current_position(segment, reader.position());
                    break;
                }
                Err(WalError::Eof) => break,
            }
        }
    }

    // Determine pending events
    let route_config = load_routes_config();
    let pending_events = Vec::new();

    for (msg_id, event) in &written {
        let targets = route_config.resolve(&event.topic);
        for target in targets {
            if !completed.contains(&(msg_id, target.consumer_id)) {
                pending_events.push(PendingEvent {
                    msg_id: *msg_id,
                    event: event.clone(),
                    target: target.clone(),
                });
            }
        }
    }

    // Rebuild dedup index
    let dedup_index: HashSet<MessageId> = written.keys().cloned().collect();

    BrokerState {
        pending_events,
        dedup_index,
        next_segment: segments.last().number + 1,
    }
}
```

### 3.2 Recovery Time Estimates

| Events in WAL | Segments | Recovery Time |
|--------------|----------|---------------|
| 10,000 | 1 | <0.5 seconds |
| 100,000 | 2-3 | ~2 seconds |
| 1,000,000 | ~15 | ~15 seconds |
| 10,000,000 | ~150 | ~2 minutes |

At 10 events/sec, 7 days retention = ~6M events. Recovery ~1.5 minutes worst case.

### 3.3 Checkpointing (Optimization)

To speed up recovery, the broker periodically writes CHECKPOINT records:

```
Every 10,000 events (configurable):
  1. Snapshot current pending event IDs
  2. Write CHECKPOINT record to WAL
  3. On recovery: find last CHECKPOINT, only process records after it
     (events in checkpoint that are still pending are pre-loaded)

Effect: Recovery only processes events since last checkpoint.
  With checkpoint every 10K events at 10 evt/s:
  Checkpoint interval: ~17 minutes
  Max events to replay: 10,000
  Recovery time: <1 second
```

## 4. Segment Compaction

### 4.1 When to Compact

```
Compaction Trigger (checked hourly by default):
  For each segment (not the active one):
    count completed events vs total events in segment
    if completed / total >= 0.8 (80%):
      → segment is eligible for compaction
```

### 4.2 Compaction Process

```
Before compaction:
  segment-000005.wal:
    [Event A: COMPLETED]
    [Event B: COMPLETED]
    [Event C: PENDING]
    [Event D: COMPLETED]
    [Event E: COMPLETED]
    [Event F: PENDING]

Compaction:
  1. Create new segment: segment-000005.wal.compact
  2. Copy only PENDING events (C, F) to new segment
  3. Add CHECKPOINT with pending event IDs
  4. fsync new segment
  5. Atomic rename: segment-000005.wal.compact → segment-000005.wal
  6. (Optional) Archive old segment as segment-000005.wal.zst

After compaction:
  segment-000005.wal:
    [CHECKPOINT: {C, F}]
    [Event C]
    [Event F]

Size reduction: 6 records → 3 records (50% in this example, typically 80%+)
```

### 4.3 Retention Policy

```yaml
# broker.yaml
wal:
  retention_hours: 168     # 7 days
  retention_action: "archive"  # "delete" | "archive"
  archive_path: "/var/lib/pulse/archive"
  archive_compression: "zstd"
```

Segments older than retention_hours where ALL events are COMPLETED are eligible for deletion/archival.

## 5. State Database (sled)

### 5.1 Key Spaces

sled is used as a fast, embedded key-value store for metadata that needs indexed access. The WAL stores raw event data; sled stores state and indexes.

```
Tree: "dedup"
  Key:   msg_id (16 bytes)
  Value: DedupEntry { stored_at: u64, topic: String }
  TTL:   7 days (cleaned up by background task)

Tree: "event_state"
  Key:   msg_id (16 bytes) + consumer_id_hash (8 bytes)
  Value: EventState { state, attempt, timestamps, last_error }

Tree: "subscriptions"
  Key:   namespace + "/" + sub_id
  Value: Subscription { topic_pattern, group, filter, consumer_id }

Tree: "consumer_offsets"
  Key:   consumer_id
  Value: ConsumerOffset { last_acked_wal_position, pending_count }

Tree: "dlq"
  Key:   msg_id (16 bytes) + consumer_id_hash (8 bytes)
  Value: DlqEntry { event, original_topic, attempts, first_error_at, last_error }
```

### 5.2 Why sled, not SQLite?

| Factor | sled | SQLite |
|--------|------|--------|
| Concurrency | Lock-free reads, designed for concurrent Rust | Single-writer, readers can block |
| Embedded | Pure Rust, no C dependency | C library, needs bindings |
| Performance | Optimized for point lookups and scans | Better for complex queries |
| Transactions | Atomic batches | Full ACID transactions |
| Fit for Pulse | Perfect: simple KV lookups on msg_id | Overkill: we don't need SQL |

### 5.3 sled Maintenance

```
Background task (every hour):
  1. Scan "dedup" tree
  2. Delete entries where stored_at + TTL < now
  3. Trigger sled compaction to reclaim space
  4. Rebuild bloom filter from remaining dedup entries
```

## 6. Memory Ring Buffer

### 6.1 Purpose

The ring buffer serves two purposes:
1. **Fast delivery**: newly routed events are served from memory, not WAL disk reads
2. **Catchup**: when a new subscriber joins with `position: "earliest"`, serve recent events from buffer instead of WAL replay

### 6.2 Design

```rust
pub struct RingBuffer {
    buffer: Vec<Option<BufferEntry>>,  // fixed-size circular buffer
    capacity: usize,                    // e.g., 100,000 entries
    write_pos: AtomicU64,              // monotonically increasing
}

pub struct BufferEntry {
    msg_id: MessageId,
    topic: String,
    payload: Bytes,         // serialized, zero-copy reference
    headers: Headers,
    wal_position: WalPosition,
    inserted_at: Instant,
}

impl RingBuffer {
    pub fn push(&self, entry: BufferEntry) {
        let pos = self.write_pos.fetch_add(1, Ordering::SeqCst);
        let index = (pos as usize) % self.capacity;
        self.buffer[index] = Some(entry);
        // Old entry at this index is overwritten (ring behavior)
    }

    pub fn read_from(&self, position: u64) -> Vec<&BufferEntry> {
        // Return entries from position to write_pos
        // If position is too old (overwritten), return what's available
    }
}
```

### 6.3 Memory Budget

| Buffer Size | Entry Size (avg) | Total Memory |
|-------------|-----------------|--------------|
| 10,000 | 1 KB | ~10 MB |
| 100,000 | 1 KB | ~100 MB |
| 1,000,000 | 1 KB | ~1 GB |

At 10 events/sec, a 100K buffer holds ~2.7 hours of events. Default: 100,000.

## 7. Disk Overflow Queue

When a consumer's in-memory delivery queue exceeds `max_pending_per_consumer`, events spill to disk:

```
/var/lib/pulse/overflow/consumer-{consumer_id}/
├── queue-000001.dat    # sequential event files
├── queue-000002.dat
└── meta.json           # { head: 1, tail: 2, count: 1500 }
```

Format is identical to WAL records (EVENT_WRITE). Events are read back sequentially when consumer catches up.

Overflow is transparent to the pipeline — the delivery queue abstraction handles memory/disk tiering automatically.
